package com.example.usbphonekeyboard

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private lateinit var editor: EditText
    private lateinit var status: TextView
    private lateinit var sendButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
            setBackgroundColor(Color.rgb(248, 249, 252))
        }
        val title = TextView(this).apply {
            text = "USB Phone Keyboard"
            textSize = 25f
            setTextColor(Color.rgb(25, 35, 55))
        }
        val subtitle = TextView(this).apply {
            text = "Type with Gboard, then send text to your Windows laptop over USB."
            textSize = 15f
            setTextColor(Color.DKGRAY)
            setPadding(0, pad / 2, 0, pad)
        }
        editor = EditText(this).apply {
            hint = "Tap here and type…"
            textSize = 18f
            gravity = Gravity.TOP or Gravity.START
            minLines = 7
            maxLines = 14
            setSingleLine(false)
            isVerticalScrollBarEnabled = true
            setPadding(pad / 2, pad / 2, pad / 2, pad / 2)
        }
        sendButton = Button(this).apply {
            text = "Send / Paste to laptop"
            isAllCaps = false
            setOnClickListener { sendText() }
        }
        val clearButton = Button(this).apply {
            text = "Clear text"
            isAllCaps = false
            setOnClickListener { editor.text.clear(); editor.requestFocus() }
        }
        status = TextView(this).apply {
            text = "Connect USB and start the Windows receiver."
            textSize = 14f
            setTextColor(Color.rgb(65, 80, 100))
            setPadding(0, pad / 2, 0, 0)
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(editor, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(sendButton)
        root.addView(clearButton)
        root.addView(status)
        setContentView(root)
        editor.requestFocus()
    }

    private fun sendText() {
        val text = editor.text.toString()
        if (text.isBlank()) {
            Toast.makeText(this, "Type or paste some text first.", Toast.LENGTH_SHORT).show()
            return
        }
        sendButton.isEnabled = false
        status.text = "Sending over USB…"
        thread {
            var connection: HttpURLConnection? = null
            try {
                connection = (URL("http://127.0.0.1:8765/paste").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 5000
                    readTimeout = 5000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                val payload = JSONObject().put("text", text).toString().toByteArray(Charsets.UTF_8)
                connection.outputStream.use { it.write(payload) }
                val code = connection.responseCode
                val stream = if (code in 200..299) connection.inputStream else connection.errorStream
                val response = stream?.bufferedReader()?.use { it.readText() } ?: ""
                val ok = code in 200..299 && JSONObject(response).optBoolean("ok", false)
                runOnUiThread {
                    status.text = if (ok) "Sent. Text was pasted into the focused Windows app." else "Send failed (HTTP $code). Check the Windows receiver."
                    if (ok) Toast.makeText(this, "Pasted to laptop", Toast.LENGTH_SHORT).show()
                    else Toast.makeText(this, "Could not send. Check USB connection.", Toast.LENGTH_LONG).show()
                    sendButton.isEnabled = true
                }
            } catch (e: Exception) {
                runOnUiThread {
                    status.text = "Connection failed. Check USB debugging, adb reverse, and receiver."
                    Toast.makeText(this, "Connection failed: ${e.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
                    sendButton.isEnabled = true
                }
            } finally {
                connection?.disconnect()
            }
        }
    }
}
