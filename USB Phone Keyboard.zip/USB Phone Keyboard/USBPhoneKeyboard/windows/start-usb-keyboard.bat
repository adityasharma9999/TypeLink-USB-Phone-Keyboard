
@echo off
setlocal
echo === USB Phone Keyboard ===

set "ADB=D:\Projects\usb keyboard folder\platform-tools\adb.exe"

if not exist "%ADB%" (
    echo ERROR: adb.exe not found at:
    echo %ADB%
    pause
    exit /b 1
)

echo Using ADB: "%ADB%"
echo.

"%ADB%" -s ZD222GGVL2 get-state
if errorlevel 1 (
    echo ERROR: Phone not detected. Check USB debugging.
    pause
    exit /b 1
)

echo.
echo Setting up USB forwarding...
"%ADB%" -s ZD222GGVL2 reverse tcp:8765 tcp:8765
if errorlevel 1 (
    echo ERROR: USB forwarding failed. Check USB debugging.
    pause
    exit /b 1
)

echo.
echo Starting receiver. Keep this window open.
cd /d "%~dp0"
py -3 receiver.py
if errorlevel 1 python receiver.py
pause
