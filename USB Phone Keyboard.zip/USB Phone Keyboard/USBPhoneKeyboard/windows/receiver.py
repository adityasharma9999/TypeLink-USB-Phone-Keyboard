#!/usr/bin/env python3
"""Local receiver for USB Phone Keyboard. Standard-library only."""
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import tkinter as tk
import ctypes
import time

HOST = "127.0.0.1"
PORT = 8765
MAX_BYTES = 100_000

def paste_text(text):
    # tkinter clipboard access must run on this main thread.
    root = tk.Tk()
    root.withdraw()
    root.clipboard_clear()
    root.clipboard_append(text)
    root.update()
    root.destroy()
    # Windows SendInput: press/release Ctrl+V.
    user32 = ctypes.windll.user32
    VK_CONTROL, VK_V = 0x11, 0x56
    KEYEVENTF_KEYUP = 0x0002
    user32.keybd_event(VK_CONTROL, 0, 0, 0)
    user32.keybd_event(VK_V, 0, 0, 0)
    time.sleep(0.04)
    user32.keybd_event(VK_V, 0, KEYEVENTF_KEYUP, 0)
    user32.keybd_event(VK_CONTROL, 0, KEYEVENTF_KEYUP, 0)

class Handler(BaseHTTPRequestHandler):
    def send_json(self, status, payload):
        raw = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(raw)

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_POST(self):
        if self.path != "/paste":
            return self.send_json(404, {"ok": False, "error": "Not found"})
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length < 1 or length > MAX_BYTES:
                return self.send_json(413, {"ok": False, "error": "Text size must be 1–100000 bytes"})
            data = json.loads(self.rfile.read(length).decode("utf-8"))
            text = data.get("text", "")
            if not isinstance(text, str) or not text:
                return self.send_json(400, {"ok": False, "error": "Text is empty"})
            paste_text(text)
            self.send_json(200, {"ok": True, "message": "Text pasted"})
        except Exception as exc:
            self.send_json(500, {"ok": False, "error": str(exc)})

    def log_message(self, fmt, *args):
        print("%s - %s" % (self.address_string(), fmt % args))

if __name__ == "__main__":
    print(f"USB Phone Keyboard receiver listening on http://{HOST}:{PORT}")
    print("Click the destination text field on Windows before sending from your phone.")
    HTTPServer((HOST, PORT), Handler).serve_forever()
