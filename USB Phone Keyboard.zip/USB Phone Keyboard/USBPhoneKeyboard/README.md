# USB Phone Keyboard (Android + Windows 11)

Use your Android phone's normal keyboard (including Gboard voice typing/autocorrect) to send text to the active Windows app over a USB cable. The Windows companion puts the received text on the clipboard and sends Ctrl+V.

## How it works
- Android app: a text field that opens your normal Android keyboard/Gboard.
- USB transport: Android Debug Bridge (ADB) reverse forwards a local TCP port over USB.
- Windows companion: accepts text only on `127.0.0.1`, writes it to the Windows clipboard, then simulates Ctrl+V.
- No Wi-Fi, Bluetooth, cloud service, or root required.

## Requirements
- Windows 11 laptop
- Android phone and a USB data cable (some cables are charge-only)
- Android Studio to build/install the Android app
- Android Platform Tools (ADB)

## 1. Prepare Windows
1. Install Android SDK Platform Tools from Google's official Android developer site: https://developer.android.com/tools/releases/platform-tools
2. Extract Platform Tools, then either add its folder to PATH or copy `adb.exe` and the accompanying DLL files into `windows/`.
3. On Windows, install Android USB driver if your phone manufacturer requires it.
4. In Android phone Settings, enable Developer options, then USB debugging.
5. Connect the phone by USB and accept the “Allow USB debugging?” prompt.
6. Open PowerShell in this project's `windows` folder and run:
   ```powershell
   .\start-usb-keyboard.bat
   ```
   Keep this terminal open. It checks ADB, starts the local receiver, and runs `adb reverse tcp:8765 tcp:8765`.

If `adb` isn't found, add the Platform Tools directory to PATH or put `adb.exe` and its required DLLs in `windows/`. The batch file assumes `adb` is available on PATH.

## 2. Build and install the Android app
1. Open the `android/` folder in Android Studio.
2. Let Gradle sync. Use JDK 17 (Android Studio's bundled JDK is fine).
3. Connect the phone with USB debugging enabled and select it as the deployment target.
4. Press Run. Alternatively build an APK with **Build > Build APK(s)** and install it on the phone.
5. Open **USB Phone Keyboard**. Tap the text field and type with Gboard. Use voice typing if enabled in Gboard.
6. Focus the target text box on Windows (click where you want the text inserted), then tap **Send / Paste to laptop** on the phone.

## Use
- Text in the app is sent to the laptop clipboard and pasted into the currently focused Windows application.
- To send a different snippet, edit the text and tap the button again.
- Keep the Windows receiver terminal running and the USB cable connected.
- To stop: close the receiver terminal. To remove forwarding, run `adb reverse --remove tcp:8765`.

## Troubleshooting
- **“Cannot connect” on phone:** confirm the Windows receiver is running and `adb reverse tcp:8765 tcp:8765` succeeded.
- **ADB says unauthorized:** unlock the phone and accept the USB debugging prompt; try `adb devices`.
- **Nothing pasted:** click the target app's text field before tapping Send. Some elevated/admin apps may block simulated input; avoid running the receiver as administrator unless you understand the security implications.
- **Phone not detected:** use a data-capable cable, try another USB port, install the phone's USB driver, and run `adb devices`.
- **Gboard not shown:** tap the text area. Android uses the currently selected input method; choose Gboard in Android keyboard settings.

## Security notes
- The receiver binds only to `127.0.0.1`, not your network.
- USB debugging grants powerful device access. Keep it enabled only while needed and only authorize your own computer.
- Do not use this on a shared/untrusted PC. Any process on the same Windows account can potentially interact with the local receiver.
- This starter app sends text only; it does not read your phone clipboard automatically or record keystrokes.
