open Android Studio and select this prj folder 
-> D:\Projects\usb keyboard folder\USBPhoneKeyboard

.\gradlew.bat assembleDebug