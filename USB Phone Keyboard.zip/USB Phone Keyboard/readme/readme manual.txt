No problem! You can rerun your USB Phone Keyboard app whenever you want, even after closing Android Studio.

## Method 1: Run the app from Android Studio again

1. Open Android Studio.
2. Click Open and select your project folder:

`D:\Projects\usb keyboard folder\USBPhoneKeyboard`

3. Wait for Gradle sync to finish.
4. Connect your phone to your laptop using a USB cable.
5. Unlock your phone and make sure USB debugging is enabled.
6. Select your physical phone (`ZD222GGVL2`) in the device dropdown, not the emulator.
7. Click the green ▶ Run button.

Your app will launch on your phone.

## Method 2: Open the app directly on your phone

If you only want to use the app, you don't need Android Studio.

1. Disconnect your phone if you want.
2. Find USB Phone Keyboard in your phone's app drawer.
3. Tap it to open.

However, to send text to your Windows computer, you must connect the phone over USB and start the Windows receiver.

## Start the Windows receiver

On your laptop, open this folder:

`D:\Projects\usb keyboard folder\USBPhoneKeyboard\windows`

Double-click:

`start-usb-keyboard.bat`

Keep the terminal window open while using the app.

My recommendation: Use Method 2 for normal use. Open Android Studio only when you want to modify the app or install a new build.